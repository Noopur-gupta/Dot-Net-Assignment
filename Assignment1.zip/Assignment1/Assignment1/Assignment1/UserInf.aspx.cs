﻿using Assignment1.BLL;
using Assignment1.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class UserInf : System.Web.UI.Page
    {
        private static int changePass;


        protected void Page_Load(object sender, EventArgs e)
        {
            

            try
            {
                var s = Request.QueryString["id"].ToString();

                if (!IsPostBack)
                {
                    UserInfBLL objBLL = new UserInfBLL();
                    UserInfBO objBO = new UserInfBO();
                    objBO= objBLL.DisplaySelected(Convert.ToInt16(s));
                    txtFirstName.Text = objBO.firstName;
                    txtLastName.Text = objBO.lastName.ToString();
                    txtJobTitle.Text = objBO.jobTitle;
                    txtEmail.Text = objBO.emailID;
                    Password.Text = objBO.password;
                    changePass = 0;
                    Session["password"] = objBO.password;
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
          


        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (changePass == 0)
                {

                    UserInfBLL objUserInfo = new UserInfBLL();
                    UserInfBO objUserInfoBO = new UserInfBO();
                    objUserInfoBO.id = Convert.ToInt16(Request.QueryString["id"]);
                    objUserInfoBO.firstName = txtFirstName.Text;
                    objUserInfoBO.lastName = txtLastName.Text;
                    objUserInfoBO.jobTitle = txtJobTitle.Text;
                    objUserInfoBO.emailID = txtEmail.Text;
                    objUserInfoBO.password = Session["password"].ToString();
                    int a= objUserInfo.UserEnterDetails(objUserInfoBO);
                    Response.Redirect("DisplayInfo.aspx");
                }
                else
                {
                    UserInfBLL objUserInfo = new UserInfBLL();
                    UserInfBO objUserInfoBO = new UserInfBO();
                    objUserInfoBO.id = Convert.ToInt16(Request.QueryString["id"]);
                    objUserInfoBO.firstName = txtFirstName.Text;
                    objUserInfoBO.lastName = txtLastName.Text;
                    objUserInfoBO.jobTitle = txtJobTitle.Text;
                    objUserInfoBO.emailID = txtEmail.Text;
                    objUserInfoBO.password = Password.Text;
                    int a= objUserInfo.UserEnterDetails(objUserInfoBO);
                    Response.Redirect("DisplayInfo.aspx");
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                Password.Enabled = true;
                Password0.Enabled = true;
                RequiredFieldValidator5.Enabled = true;
                rfvConfirmPassword.Enabled = true;
                cvConfirmPassword.Enabled = true;
                revPassword.Enabled = true;

                changePass = 1;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
           
        }
        
        
    }
}