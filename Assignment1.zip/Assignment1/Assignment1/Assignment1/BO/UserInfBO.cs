﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment1.BO
{
    public class UserInfBO
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string emailID { get; set; }
        public string jobTitle { get; set; }
        public string password { get; set; }
        public int id { get; set; }
    }
}