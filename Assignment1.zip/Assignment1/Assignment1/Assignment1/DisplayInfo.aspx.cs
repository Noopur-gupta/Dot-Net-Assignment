﻿using Assignment1.BLL;
using Assignment1.BO;
using Assignment1.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class DisplayInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
           
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                string[] arr = new string[30];
                string searchString = SearchBox.Text;
                int wildcard = 0;
                for (int i = 0; i < searchString.Length; i++)
                {
                    if (searchString[i] == '%')
                        wildcard = 1;
                    else if (searchString[i] == ' ')
                    {
                        arr = searchString.Split(' ');
                        wildcard = 2;
                    }
                }
                if (wildcard == 1)
                {
                    ViewAll.Visible = true;
                    GridView1.Visible = false;
                    gridView2.Visible = true;
                    DisplayInf obj = new DisplayInf();

                    List<UserInfBO> obj1 = obj.searchDataWildCardManager(searchString);
                    if (obj1.Count == 0)
                        Nodata.Visible = true;
                    else
                        Nodata.Visible = false;
                    gridView2.DataSource = obj1;
                    gridView2.DataBind();
                }
                else if (wildcard == 2)
                {
                    ViewAll.Visible = true;
                    GridView1.Visible = false;
                    gridView2.Visible = true;
                    DisplayInf obj = new DisplayInf();
                    List<UserInfBO> obj1 = obj.searchDataManager(arr[0], arr[1]);
                    if (obj1.Count == 0)
                        Nodata.Visible = true;
                    else
                        Nodata.Visible = false;
                    gridView2.DataSource = obj1;
                    gridView2.DataBind();

                }
                else
                {
                    ViewAll.Visible = true;
                    GridView1.Visible = false;
                    gridView2.Visible = true;
                    DisplayInf obj = new DisplayInf();

                    List<UserInfBO> obj1 = obj.searchDataOneWordManager(searchString);
                    if (obj1.Count == 0)
                        Nodata.Visible = true;
                    else
                        Nodata.Visible = false;
                    gridView2.DataSource = obj1;
                    gridView2.DataBind();
                }


            }
             catch (Exception ex)
             {
              Console.WriteLine(ex.Message);
             }
        }

        protected void ViewAll_Click(object sender, EventArgs e)
        {
            try
            {
                GridView1.Visible = true;
                gridView2.Visible = false;
                ViewAll.Visible = false;
            }
            catch (Exception ex)
            {
                
               Console.WriteLine(ex.Message);
            }
        }
    }
}