﻿using Assignment1.BO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Assignment1.DAL
{
    public class DisplayInfDAL
    {

        public List<UserInfBO> searchData(string firstName,string lastName)
        {
            SqlConnection con = new SqlConnection();
            List<UserInfBO> objarray = new List<UserInfBO>();
            try
            {
                
                con.ConnectionString = "Data Source=01HW593023\\SQLEXPRESS;Initial Catalog=Assignment1;Integrated Security=True";
                SqlCommand com = new SqlCommand();

                com.Connection = con;

                con.Open();

               
                UserInfBO a;

                //string query = String.Format("Select * from Users where firstName='{0}' or lastName='{1}' or email='{2}'",m,m,m);
                //com.CommandText = query;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "SearchNormal";
                com.Parameters.AddWithValue("n", firstName);
                com.Parameters.AddWithValue("m", lastName);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    a = new UserInfBO();
                    a.id = Convert.ToInt16(dr["id"].ToString());
                    a.firstName = dr["firstName"].ToString();
                    a.lastName = dr["lastName"].ToString();
                    a.emailID = dr["email"].ToString();
                    a.jobTitle = dr["jobTitle"].ToString();
                    a.password = dr["userPassword"].ToString();
                    objarray.Add(a);
                }
                dr.Close();
                
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return objarray;

        }


        public List<UserInfBO> searchDataWildCard(string wildcardstring)
        {
            SqlConnection con = new SqlConnection();
            List<UserInfBO> objarray = new List<UserInfBO>();
            try
            {
                con.ConnectionString = "Data Source=01HW593023\\SQLEXPRESS;Initial Catalog=Assignment1;Integrated Security=True";
                SqlCommand com = new SqlCommand();

                com.Connection = con;

                con.Open();


                UserInfBO a;


                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "SearchStringWildCard";
                com.Parameters.AddWithValue("m", wildcardstring);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    a = new UserInfBO();
                    a.id = Convert.ToInt16(dr["id"].ToString());
                    a.firstName = dr["firstName"].ToString();
                    a.lastName = dr["lastName"].ToString();
                    a.emailID = dr["email"].ToString();
                    a.jobTitle = dr["jobTitle"].ToString();
                    a.password = dr["userPassword"].ToString();
                    objarray.Add(a);
                }
                dr.Close();
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return objarray;

        }


        public List<UserInfBO> searchDataOneWord(string searchString)
        {
            SqlConnection con = new SqlConnection();
            List<UserInfBO> objarray = new List<UserInfBO>();

            try
            {
                con.ConnectionString = "Data Source=01HW593023\\SQLEXPRESS;Initial Catalog=Assignment1;Integrated Security=True";
                SqlCommand com = new SqlCommand();

                com.Connection = con;

                con.Open();


                UserInfBO a;


                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "SearchStringOneWord";
                com.Parameters.AddWithValue("search", searchString);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    a = new UserInfBO();
                    a.id = Convert.ToInt16(dr["id"].ToString());
                    a.firstName = dr["firstName"].ToString();
                    a.lastName = dr["lastName"].ToString();
                    a.emailID = dr["email"].ToString();
                    a.jobTitle = dr["jobTitle"].ToString();
                    a.password = dr["userPassword"].ToString();
                    objarray.Add(a);
                }
                dr.Close();
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return objarray;

        }
    
    }
}