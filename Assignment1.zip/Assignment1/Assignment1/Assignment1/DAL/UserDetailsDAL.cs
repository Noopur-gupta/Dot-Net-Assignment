﻿using Assignment1.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace Assignment1.DAL
{
    public class UserDetailsDAL
    {
        public int enterDetails(UserInfBO user)
        {
            int n = 0;
            SqlConnection con = new SqlConnection();
            try
            {
                
                con.ConnectionString = "Data Source=01HW593023\\SQLEXPRESS;Initial Catalog=Assignment1;Integrated Security=True";
                SqlCommand com = new SqlCommand();

                com.Connection = con;

                con.Open();

                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "UpdateUserDetails";

                com.Parameters.AddWithValue("userId", user.id);
                com.Parameters.AddWithValue("firstName", user.firstName);
                com.Parameters.AddWithValue("lastName", user.lastName);
                com.Parameters.AddWithValue("email", user.emailID);
                com.Parameters.AddWithValue("jobTitle", user.jobTitle);
                com.Parameters.AddWithValue("userPassword", user.password);
                n = com.ExecuteNonQuery();

              

               
            }
            catch
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return n;
              
             }
        public UserInfBO DisplaySelected(int id)
        {
            UserInfBO objUserInfo = new UserInfBO();
           
            SqlConnection con = new SqlConnection();
            try
            {
                
                con.ConnectionString = "Data Source=01HW593023\\SQLEXPRESS;Initial Catalog=Assignment1;Integrated Security=True";
                SqlCommand com = new SqlCommand();

                com.Connection = con;

                con.Open();
                string query = String.Format("Select * from Users where id='" + id + "'");
                com.CommandText = query;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    objUserInfo.firstName = dr["firstName"].ToString();
                    objUserInfo.lastName = dr["lastName"].ToString();
                    objUserInfo.emailID = dr["email"].ToString();
                    objUserInfo.jobTitle = dr["jobTitle"].ToString();
                    objUserInfo.password = dr["userPassword"].ToString();
                }
                dr.Close();
               
            }


            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return objUserInfo;

        }
    }
}