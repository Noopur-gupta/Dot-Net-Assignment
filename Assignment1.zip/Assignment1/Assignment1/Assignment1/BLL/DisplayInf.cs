﻿using Assignment1.BO;
using Assignment1.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment1.BLL
{
    public class DisplayInf
    {
        public List<UserInfBO> searchDataManager(string m,string n)
        {
          DisplayInfDAL a= new DisplayInfDAL();
           List<UserInfBO> objBO= a.searchData(m,n);
            return objBO;
        }

        public List<UserInfBO> searchDataWildCardManager(string m)
        {
          DisplayInfDAL a= new DisplayInfDAL();
           List<UserInfBO> objBO= a.searchDataWildCard(m);
            return objBO;
        }


        public List<UserInfBO> searchDataOneWordManager(string m)
        {
            DisplayInfDAL a = new DisplayInfDAL();
            List<UserInfBO> objBO = a.searchDataOneWord(m);
            return objBO;
        }
    }
}