﻿using Assignment1.BO;
using Assignment1.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment1.BLL
{
    public class UserInfBLL
    {
           public  int UserEnterDetails(UserInfBO user)
           {
               UserDetailsDAL a = new UserDetailsDAL();
               int ab=a.enterDetails(user);
               return ab;
           }
           public UserInfBO DisplaySelected(int id)
           {
               UserDetailsDAL a = new UserDetailsDAL();
               UserInfBO objBO = a.DisplaySelected(id);
               return objBO;
           }
    }
}